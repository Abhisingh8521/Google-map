package com.example.myapplication

import android.Manifest
import android.annotation.SuppressLint
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.location.Geocoder
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationServices
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.SupportMapFragment
import com.google.android.gms.maps.model.CircleOptions
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.MarkerOptions
import com.google.android.gms.maps.model.PolylineOptions
import java.util.*


class MainActivity : AppCompatActivity() {
    private lateinit var fusedLocationClient: FusedLocationProviderClient
    private var perReq = 121;
    private var places = ArrayList<Place>()
    val TamWorth = LatLng(-31.083332, 150.916672)
    val NewCastle = LatLng(-32.916668, 151.750000)
    val Brisbane = LatLng(-27.470125, 153.021072)
    private lateinit var googlemap: GoogleMap
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        fusedLocationClient = LocationServices.getFusedLocationProviderClient(this)



        places.add(Place("Sk", LatLng(12.12, 11.2), LatLng(12.12, 11.2), 4.5F))
        places.add(Place( "my location",LatLng(10.12, 10.2),LatLng(12.12, 11.2) ,4.5f) )
        places.add(Place( "my location",LatLng(13.12, 10.2),LatLng(14.12, 11.2) ,4.5f) )

        val mapFragment = supportFragmentManager.findFragmentById(
            R.id.map
        ) as? SupportMapFragment
        mapFragment?.getMapAsync { googleMap ->
            googlemap = googleMap

            googleMap.addMarker(
                MarkerOptions()
                    .title("Bheldi")
                    .position(LatLng(70.034988, 72.2895683))
            )
            addMarkers(googleMap)
        }

        checkPer()
    }

    private fun checkPer() {
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED
            && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED
        ) {

            ActivityCompat.requestPermissions(
                this,
                arrayOf(android.Manifest.permission.ACCESS_FINE_LOCATION,android.Manifest.permission.ACCESS_COARSE_LOCATION ),
                perReq
            )
            return
        } else {
            getCurrentLocation(fusedLocationClient)
        }


    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)

        if (requestCode == perReq && resultCode == RESULT_OK) {
            checkPer()
        }
    }

    /**
     * Adds marker representations of the places list on the provided GoogleMap object
     */
    @SuppressLint("MissingPermission")
    private fun getCurrentLocation(fusedLocationClient: FusedLocationProviderClient) {
        fusedLocationClient.lastLocation.addOnSuccessListener {
            val geocoder = Geocoder(this, Locale.getDefault())
            val addresses = geocoder.getFromLocation(it.latitude, it.longitude, 1)
            val address = addresses?.get(0)?.getAddressLine(0)
            places.add(
                Place(
                    address.toString(),
                    latLng = LatLng(it.latitude, it.longitude),
                    LatLng(it.latitude, it.longitude),
                    4.5F
                )
            )
//                Toast.makeText(this, address.toString(), Toast.LENGTH_SHORT).show()
            addMarkers(googlemap)
            googlemap.animateCamera(CameraUpdateFactory.newLatLngZoom(LatLng(it.latitude, it.longitude),14F))
            googlemap.addCircle(
                CircleOptions()
                    .center(LatLng(it.latitude, it.longitude))
                    .radius(1000.0)
                   // .fillColor(ContextCompat.getColor(this,R.color.teal_200))
                    .strokeColor(ContextCompat.getColor(this, R.color.white))
            )
        }
    }

    private fun addMarkers(googleMap: GoogleMap) {
        places.forEach { place ->
            val marker = googleMap.addMarker(
                MarkerOptions()
                    .title(place.name)
                    .position(place.latLng)
            )
            marker?.tag = place

        }
        onMapReady(googlemap)
    }

    private fun onMapReady(googleMap: GoogleMap) {
        var mMap = googleMap
        // inside on map ready method
        // we will be displaying polygon on Google Maps.
        // on below line we will be adding polyline on Google Maps.
        mMap.addPolyline(
            PolylineOptions().add(Brisbane, NewCastle, TamWorth, Brisbane,places[places.size-1].latLng)
                .width // below line is use to specify the width of poly line.
                    (15f) // below line is use to add color to our poly line.
                .color(Color.GRAY) // below line is to make our poly line geodesic.
                .geodesic(true)
        )
        // on below line we will be starting the drawing of polyline.
        googleMap.moveCamera(CameraUpdateFactory.newLatLngZoom(places[places.size-1].latLng, 10f))
    }
}